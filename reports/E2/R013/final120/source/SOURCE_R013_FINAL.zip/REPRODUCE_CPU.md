# R013 CPU source reproduction

Exact acquisition code Head79510d9a302eeb7820f7ed35463c29bc649e1431. This ZIP contains no reviewer grant, weights, unsafe snapshot or private original. It cannot authorize new TEST.

Use an isolated Python3.12.14 environment with NumPy1.26.4. CPU-only tests:

    CUDA_VISIBLE_DEVICES=-1 OPENBLAS_NUM_THREADS=1 python -m unittest discover -s tests -v
    CUDA_VISIBLE_DEVICES=-1 OPENBLAS_NUM_THREADS=1 python -O -m unittest discover -s tests -v

Tests use real CPU subprocess proxies and explicitly synthetic temporary Git grants. They do not run GR00T/MuJoCo or consume TEST IDs.

Historical actual audit needs a full-history repository including independent main reviews/closed-prefix registry, all unmerged exact source/report objects and legally accessible verified raw originals. Never infer historical provenance from this ZIP alone. Auditing does not unpickle snapshots or start a model/simulator.

Original120 frozen IDs are single-use; historical R008/R011/R012 are suspended for acquisition. R013 only permits GPU1 original0085 onward under its signed live resource and checkpoint conditions. Original120 collection completed after full92 source/exit/two-location reconciliation and owner-requested continuation under unchanged active R013. Three historic cleanup errors remain censored. No additional TEST IDs or model requests are proposed; independent R3 result review and owner submission remain pending. An experiment's completed or failed IDs cannot be repeated through packaging/reproduction. No fresh model/TEST request is proposed by this course package.
