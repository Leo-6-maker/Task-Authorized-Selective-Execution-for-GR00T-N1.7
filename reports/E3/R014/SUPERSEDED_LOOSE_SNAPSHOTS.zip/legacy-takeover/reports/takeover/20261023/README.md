# 接手 CPU 检查与现场盘点收据

日期：2026-10-23（Asia/Singapore）。角色：Codex executor。源码 SHA：`7e73108fd87a711b4cdc339d93749cc4add3628f`。全部测试使用仓库已有合成 fixtures；没有模型请求、真实仿真、DEV 或 shadow 消耗。

本机使用现有 `/usr/bin/python3`，Python 3.10.12 / NumPy 1.21.5。不是历史物理环境 Python 3.12.14；没有安装或替换环境。每个 JSON 收据记录完整命令、SGT 时间、退出码、源码 SHA、版本及日志 SHA-256，日志中的本地仓库绝对路径替换为 `<REPO>`。

| 实际检查 | 结果 | 收据与日志 |
|---|---|---|
| `python3 -m unittest discover -s tests -v` | 24 个测试方法；exit 1；21 个 error/subtest error | [normal.json](normal.json)、[normal.txt](normal.txt) |
| 对应 `python3 -O` 完整 suite | 同上，exit 1 | [optimized.json](optimized.json)、[optimized.txt](optimized.txt) |
| `PYTHONPATH=tests python3 -m unittest test_m2_cpu test_oracle_inputs -v` | 11 个测试通过，exit 0 | [oracle-normal.json](oracle-normal.json)、[oracle-normal.txt](oracle-normal.txt) |
| 对应 `python3 -O` 定向 suite | 11 个测试通过，exit 0 | [oracle-optimized.json](oracle-optimized.json)、[oracle-optimized.txt](oracle-optimized.txt) |

完整 suite 的 21 个错误均为 `AttributeError: module 'hashlib' has no attribute 'file_digest'`，触发于已有 `tase/evidence.py`，包括 19 个单一损坏 subtest 的 fixture 构造和两个 manifest 相关方法。它们没有完成实际断言，不能计为负样本通过。`hashlib.file_digest` 要求 Python 3.11+；本轮保留失败，没有改冻结代码、增加兼容 shim 或重装环境来制造 PASS。

定向 11 项覆盖当前 oracle 输入校验/历史与 sticky violation 原子性、有效输入、跨 chunk 事件、授权/错误物体区分、事件边界及纯 CPU snapshot/helper 等合成逻辑。它们均在初次完整 suite 中通过；随后单独运行以产生可独立复核的退出码。这不是完整 suite 通过，也不替代 R003 要求的旧有效原始帧重审、阳性物理窗口补验或 GPT 审核。

现场 SSH 盘点只查询文件名、Git 身份、GPU 元数据与可读进程；未创建远端环境、复制代码、启动 GPU 工作负载或修改运行账本。详细结果见[接手报告](../../../TAKEOVER_REPORT.md)。
