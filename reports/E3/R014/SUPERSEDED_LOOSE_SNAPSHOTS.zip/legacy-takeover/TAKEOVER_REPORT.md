# 接手盘点报告

日期：2026-10-23（Asia/Singapore）。角色：Codex executor。范围：GitHub 接手、本机及指定计算节点只读盘点、已有合成 CPU 检查和文档交付。

**总体状态：GITHUB_TAKEOVER_COMPLETED / RUNTIME_EVIDENCE_UNVERIFIED。** 负责人已明确没有本地交接目录，改为从 GitHub 接手，并指定经 Corelab 登录计算节点。已核实该双跳免密链路、计算节点 GPU 与可读进程，完成有界目录检索；本项目 checkout、共享账本和 R003 原始运行收据仍未定位，部分 NAS 候选目录无读权限。不能将未取得证据写成未运行、已通过或尚有六个 shadow 名额。

## 1. 本轮边界与已读资料

- 项目仅为原生 GR00T N1.7 LIBERO-Object 的任务授权 Safety Gate；无 WBC、额外训练、实机。
- 已读仓库 `AGENTS.md`、`docs/STATUS.md`、`docs/CODEX_HANDOFF.md`、`docs/REVIEW_WORKFLOW.md`、最新 GPT 审核 R003、M2 工作包，以及实时 Issue #4（含四条评论）、PR #3/#5 描述与评论、PR #5 review 列表。
- 已读当前 PR #5 分支中的 R003 计划、配置、输入契约修复、补验脚本、补验 CPU 审计器、相关测试源码及历史运行身份。
- 负责人已明确不存在可提供的本地交接目录；`START_HERE.md` 与 `private/runtime-map.local.yaml` 未作为已读资料。本轮依据 GitHub 与指定 SSH 链路推进，不再将提供这两个文件列为接手前提。其他科研项目的同名文件未用作本项目依据。
- 本轮未启动 GPU 工作负载、模型、仿真或补验；未安装环境、下载权重、修改账本、清理数据、回退代码、提交/push/合并 PR，未向 GitHub 发布消息。已切至实时 PR #5 分支，执行已有纯合成 CPU 测试，并更新本报告、状态索引、CPU 入口说明及测试收据。

## 2. 实时 GitHub 与本地代码

### 2.1 实时 refs

使用 GitHub connector 读取 PR 元数据，并用公开 GitHub REST 与 `git ls-remote` 交叉核对；下表记录实际返回值，不采用 PR 描述中的旧 head。

| 对象 | head/ref | 完整 SHA | 状态 |
|---|---|---|---|
| 远端 main 分支 | `main` | `7e4a67a9ee21787c102a8791066cc63931f55a53` | 审核/计划分支 |
| PR #3 head | `codex/2-native-baseline` | `3e214c0b761d0639bf73948356a92a03bf2ddedc` | OPEN / 未合并 |
| PR #3 base（PR API 返回） | `main` | `1defcf01b26e908cc17512780eaacc074a3547fc` | 与实时 main 分支 tip 不同，分别保留身份 |
| PR #5 head | `codex/4-m2-shadow-oracle` | `7e73108fd87a711b4cdc339d93749cc4add3628f` | OPEN / 未合并 |
| PR #5 base | `codex/2-native-baseline` | `3e214c0b761d0639bf73948356a92a03bf2ddedc` | stacked parent 与 PR #3 head 相符 |

PR #5 描述及旧交付评论仍绑定 `d64cb1002980738f170e3206d004b4a882166543`、DEV 18/24、shadow 74/80。这些是历史交付身份，不能覆盖实时 head，也不能证明当前共享账本仍为 74。

来源：[Issue #4](https://github.com/Leo-6-maker/Task-Authorized-Selective-Execution-for-GR00T-N1.7/issues/4)、[PR #3](https://github.com/Leo-6-maker/Task-Authorized-Selective-Execution-for-GR00T-N1.7/pull/3)、[PR #5](https://github.com/Leo-6-maker/Task-Authorized-Selective-Execution-for-GR00T-N1.7/pull/5)。

### 2.2 本地 checkout

路径：`<OWNER_WORKSPACE>`。

- 初次盘点分支为 `main`，HEAD 为 `7e4a67a9ee21787c102a8791066cc63931f55a53`。继续接手后已使用 `git switch --track origin/codex/4-m2-shadow-oracle`，当前本地分支为 `codex/4-m2-shadow-oracle`，HEAD 为 `7e73108fd87a711b4cdc339d93749cc4add3628f`。
- 盘点开始时工作区及 index 干净，`main...origin/main` ahead/behind 为 **0/0**，无 stash，只有一个 worktree。之后增加跟踪现有远端的 M2 本地分支；没有丢弃已有工作。
- 两个实现分支的 remote-tracking refs 与本次实时远端 refs 一致；当前 M2 本地分支与其远端 head 相同，没有未推送提交。
- 所检索的本地项目位置只找到此 checkout；不能据此排除未迁入本机的旧 Windows checkout 或尚未提供的交接目录。
- 本 checkout 没有 `runs/`、`local/`、`artifacts/private/` 或 `private/` 原件目录。当前新增接手报告及 CPU 收据，修改状态索引和 README；既有执行 Python 代码、历史审核、配置和账本均未修改。

### 2.3 Corelab checkout 与权限

| 检查 | 结果 | 能支持的结论 |
|---|---|---|
| GitHub connector 读取 Issue/PR | 成功 | GitHub 读取权限可用；未测试写权限 |
| Git 远端 refs 查询 | 成功 | 远端分支与 PR head 可实时核对 |
| 既有 Corelab SSH 配置入口 | 非交互连接成功，退出码 0 | 此入口的 SSH 登录与只读命令执行可用 |
| 主机校验 | 保持开启 | 未关闭 host-key 校验或打印凭据 |
| 指定计算节点双跳 SSH | 非交互登录成功 | 已落实负责人指定链路；GPU 盘点与进程查询 exit 0 |
| 本项目运行 workspace | 未定位 | 硬件记录相符不能替代 checkout、运行身份与原件绑定 |
| Corelab 项目 HEAD、脏文件、stash、未推送提交 | **NOT_VERIFIED** | 必须取得 runtime map 后在准确 checkout 复核 |

在登录节点和指定计算节点的项目目录、临时目录、磁盘/NAS 位置做了有界文件名及仓库 origin 检索。部分搜索超时或遇权限拒绝，详见第 8 节；不能声称扫描了所有存储。未使用其他科研项目的 Python、源码、模型或证据替代本项目资源；内部主机地址、账号、SSH 配置及完整进程参数不写入本报告。

## 3. 既有运行身份与原始证据定位

以下是**当前 PR 分支保存的历史运行身份**，不是本轮对远端磁盘的验证结果。

| 组件 | 历史锁定身份 |
|---|---|
| M2 物理运行代码 | `16f0249299a11805666f68eb06c09c8f3974efef` |
| M2 后处理代码 | `7b3ccdec283bb565864ffba726d479b13d01de90` |
| NVIDIA/Isaac-GR00T 源码 | `dac54b313160c201c450f97df0fd74ebd379c892` |
| LIBERO 源码 | `8f1084e3132a39270c3a13ebe37270a43ece2a01` |
| Object 模型 | `nvidia/GR00T-N1.7-LIBERO` / `2ea293aa20ba7cf5bbf3ba17a5fbcb1a01cbfe21` / `libero_object` |
| 原生辅助 backbone | `nvidia/Cosmos-Reason2-2B` / `9ce19a195e423419c349abfc86fd07178b230561` |
| server Python / 核心包 | Python 3.12.14、NumPy 1.26.4、Torch 2.9.0+cu128 |
| sim Python / 核心包 | Python 3.12.14、NumPy 1.26.4、MuJoCo 3.3.1、robosuite 1.4.0 |
| 运行契约 | LIBERO_PANDA、原生 wrapper/controller/gripper、policy horizon 16、执行前缀最多 8、episode 上限 720 controls |

`configs/runtime_lock_m2.json` 的本地 Git blob SHA-256 已复算为 `fb73e0b4e5d6723ca0425030f0e25eeaca61b322d9fd8b7988a092b60c5f7bda`；历史验证配置 SHA-256 为 `f56f1dc7be7ff7becc1b62ff4327948e6f44ef2272f97f459151f60098917dc0`。哈希匹配说明读取了相应版本的锁文件，不证明磁盘上的权重或解释器当前匹配。

源码声明的逻辑布局为 task-owned workspace 下的 `course-repo/`、`upstream/Isaac-GR00T/`、`runtime/`、`cache/`、`runs/`。**现有 server/sim Python 的绝对路径、固定源码实际路径、模型缓存与证据存储实际路径均待 runtime map 确认**。不依据路径惯例新建或重装环境。

待定位的历史脱敏原件包：

| 原件包 | 已有声明 SHA-256 | 本轮状态 |
|---|---|---|
| `R002-private-sanitized-originals.zip` | `d0d317ee83226ce3dd34a654468636b43deb8cae5a959b4fe628fda5ba3eba98` | 未取得文件字节，未复算归档 |
| `M2-private-sanitized-originals.zip` | `859b177e097fab1c88449d30afcf3c2d2175256ecdb795793cc9a517de9737a2` | 未取得文件字节，未复算归档 |

GPT 独立原件/媒体审核仍为 **NOT_VERIFIED_BY_REVIEWER**；本执行者不能关闭该项。

## 4. 共享账本、最后运行与活动进程

| 项目 | 已核实的历史记录 | 当前现场状态 |
|---|---|---|
| DEV | M1 12 次 + M2 6 次 = **18/24**；另外六次保留 | 实际共享目录/账本未取得；无新增 DEV 授权 |
| shadow | 原始表 **74/80**、24 个不同 snapshot、589 predicted controls | 六个补验槽可能已消费；**剩余额度 UNKNOWN，不视为 6** |
| M2 源采集 | 249 次模型调用、1,985 controls | 历史公开汇总；未重审原件 |
| M2 model server | `server-m2-01`，历史报告与 lock 记录实际 child exit 0 | 未取得当前原始 exit 收据；不能认定它是现场最后一次运行 |
| M1 旧 server-01 | PR #3 明确保留旧 child exit `NOT_CAPTURED` | 不补造历史退出码 |
| R003 定向补验 | 当前 head 有入口和审计器 | 最后运行时间、运行 SHA、结果、父/子退出码、失败槽数均 **NOT_VERIFIED** |
| 本机活动进程 | 在可读 `/proc` 中按项目标志未发现匹配项 | 仅本次有限观测 |
| 登录节点及指定计算节点活动进程 | 在可读 `/proc` 中按项目标志未发现匹配项 | 仅本次可读进程观测；不证明任务从未执行或无法读取的进程不存在 |

公开 `reports/M2/budget_ledger.json` 和 `snapshot_validation.csv` 均仍表示原始 74 次比较；后者本轮只读复算为 74 行。原表按 R003 必须保持不变，因此没有新增行**不能证明补验未执行**。

## 5. R003：代码、执行和审核分别判断

| 项目 | 代码状态 | 运行/证据状态 | 审核状态 |
|---|---|---|---|
| PR #3 / R002 修复 | `3e214c0…` 已实现 observation/parity/manifest 加固和异常留证 | 历史执行者报告已重审原件；本轮未重复运行 | R003 认可所审代码及定向 CPU 结果；原件独立审核未完成，未获合并许可 |
| R003 F2 oracle 输入契约 | `307fd4f7416c48df5f922300791f58832775a1e3` 已加入 schema/type/shape/finite/quaternion 检查，在历史状态变化前拒绝非法输入；加入合成回归测试 | 本轮当前 head 的 11 项 M2/oracle 合成 CPU 测试 normal/-O 均通过；旧私有有效帧重审仍未取得，完整 suite 另有环境失败 | 最新 GPT R003 针对旧 `d64cb100…`，不能自动覆盖该新修复 |
| R003 F1 阳性窗口补验 | 同一提交已冻结 source017 d009 → pre-d011/pre-d012 配置和旧动作补验入口 | 未取得结果/exit/共享 reservation，**无法判定已经运行或尚未运行** | 原 R003 仅提供有条件、有预算的补验授权，不是结果批准 |
| R003 补验 CPU 审计 | `7e73108fd87a711b4cdc339d93749cc4add3628f` 已加入 `scripts/audit_m2_r003.py` | 存在审计代码不代表已运行、通过或已取得原始证据 | 未发现绑定当前 head 的后续 GPT review |
| R003 F3 原件可访问性 | 不以代码提交替代原件交付 | 两个旧 ZIP 本轮均未获得 | 仍开放 |

`d8b1a3ec0c3c2412107149aa5b6cad81f8a83436` 已将包含 R003 的 main 合入 M2 分支；之后才有上述两个实现提交。本轮保留当前代码，没有根据旧描述回退。

当前最新 GPT 决议为 [R003](docs/reviews/R003-M2-shadow-oracle-review.md)，绑定 PR #5 的 `d64cb1002980738f170e3206d004b4a882166543`。新 head 应分别标记为 **IMPLEMENTED / TARGETED_CPU_TESTED_LOCALLY / RUNTIME_NOT_VERIFIED_IN_TAKEOVER / CURRENT_HEAD_REVIEW_PENDING**，不能写 `REVIEWED` 或 `APPROVED`。

另：初始 main 和 M2 分支的 `docs/STATUS.md` 均仍以 R002 为最新审核，并保留旧 PR #3 head；main 还含“shadow 尚未实现”的过期描述。本轮已在本地 M2 分支更新状态索引，绑定 R003 及当前 head，分别列出代码、运行和审核状态；历史审核文件不变。

## 6. 防重复核对清单与下一步

后续若取得项目实际工作区或原始证据的可读访问，优先完成以下只读核对，不启动补验：

1. 从负责人提供的实际位置或获授权的既有存储中定位项目 checkout 和原件；不要求创建不存在的交接文件，不公开内部连接信息。
2. 对准确 Corelab checkout 检查 HEAD、upstream、所有 worktree、status、stash 与 ahead/behind；保存已有未提交/未推送工作身份，禁止 reset/覆盖。
3. 核对既有 server/sim Python、固定源码与模型目录的实际存在性及锁定身份，不通过导入模型、GPU 初始化或环境重装进行探测。
4. 读取实际 `runs/episodes` 与共享 `runs/m2_shadow` reservations，含 STARTED/ERROR/失败/中断槽；核对 ordinal 75–80 是否已用。保留原 24/74 表。
5. 优先找 `runs/m2-r003-01/identity.json`、`result.json`、`preflight_error.json`、`cleanup.jsonl`、`artifact_manifest.json`、`runs/m2-r003-01.exit.json`，以及 checks/operator ledger；若有其他 run-id，同样列入。确定最后一次执行 SHA、命令、时间与真实父/子退出码。
6. 对照 `r003-dev-m2-017-d011-r0..r2`、`r003-dev-m2-017-d012-r0..r2` 的 reservation/result/noninterference 和审计收据，判断已完成、失败消耗或只完成部分；不得仅凭汇总 PASS 或脚本存在决定续跑。
7. 根据现场信息更新本报告。只有确认实际未完成且已获授权的 CPU 修复/旧证据整理才继续；本轮明确禁止启动 GPU/模型/仿真。shadow 名额不足、原件不全或重放失败时停止运行路径并交付事实。

当前限制是**准确项目工作区及原件尚未定位，部分候选存储不可读**。GitHub 明确省略了内部路径，公开代码及旧汇总不能恢复当前 reservation 的消费事实。无需重新授权已允许的只读盘点，但无法用新运行替代这些缺失信息。

## 7. 授权与交付结论

本轮已完成可访问范围内的 GitHub、代码、本机及指定计算节点盘点，并推进已有合成 CPU 检查和状态文档整理。现场原始账本及 R003 执行状态仍未闭合；没有证据支持把历史剩余 shadow 名额当成可用名额，也没有证据支持重跑 R003 或新建模型请求。

**不进入 M3、真实 Gate 干预、CALIB 或 TEST；不消费保留六次 DEV；不新增模型请求；不合并任一 PR。** Codex 负责事实记录、实现与证据交付，GPT 负责对准确 head 与可访问原件作审核决定。


## 8. 指定计算节点只读检索结果（负责人后续指令）

- 已落实经登录节点到负责人指定计算节点的双跳免密 SSH；保留主机密钥校验，未创建或修改 SSH 配置、未输出秘密。
- 只读 `nvidia-smi` exit 0：两块 RTX 4080 SUPER 分别报告总显存 32760 / 16376 MiB、已用 481 / 38 MiB、GPU utilization 0 / 0%。第一块总量与历史预检相符，但未将此当作运行身份或新 GPU 使用许可。
- 在计算节点可读 `/proc` 的命令行和 cwd 中检索 TASE、ME6401、course-repo、shadow/supplement、GR00T/LIBERO 标志，未发现匹配进程。完整参数、环境及内部账号不保存到公开材料。
- 找到两个已有 GR00T 源码候选，均为 `51d4c89f72fda44cbf77285c6a8114b52676b8a1`；一个有 2 项 tracked 改动，另一个 tracked 工作区干净。两者都不匹配本项目上游 pin `dac54b313160c201c450f97df0fd74ebd379c892`，且候选下未找到 `.venv/bin/python` 或 `libero_uv/bin/python`。未触碰其改动、借用其环境或声称它们是本项目 checkout。
- 计算节点系统 Python 为 3.12.3，默认解释器未发现 NumPy 安装；它不是项目锁定的 Python 3.12.14 server/sim 环境，没有用它替代既有环境。
- 两个 NAS 工作区候选根目录返回 PermissionError；非交互只读提权查询亦失败，未尝试密码、改变权限或绕过限制。HomeNFS 检索观察到权限拒绝；HomeArchive 搜索触发有界 timeout；课程存储有界检索完成但未命中本项目。未将这些不完整检索写成“服务器没有项目”。
- 一个较早的通用扫描因无权 stat 某临时目录中止，另一个触发时间上限；后续改用跳过权限错误的有界检索。它们不是本项目运行失败或 DEV/shadow 消耗。

## 9. 本轮已推进的 CPU 工作

当前 head 的 11 项 M2/oracle 合成测试在普通及 `-O` 模式下均 exit 0。首次完整 suite 两种模式均 exit 1：Python 3.10.12 缺少 `hashlib.file_digest`，产生 21 个 error/subtest error（24 个测试方法）。没有将未运行到断言的损坏 fixture 计为通过，没有修改执行代码或安装新环境。完整命令、SGT 时间、版本和日志哈希见 [CPU 检查收据](reports/takeover/20261023/README.md)。这些结果不替代私有原件重审、阳性物理补验或 GPT 审核。
